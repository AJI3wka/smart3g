# smartspeed3g
